import pickle
import re
from datetime import datetime
from tkinter import messagebox

from sklearn.impute import SimpleImputer
import pandas as pd

ER_ARRIVAL_DATE = "תאריך הגעה למיון"
WALKING_ER = "מיון מהלכים"
INTERNAL_ER = "מיון פנימי"
INTERNAL_ER_INF = "רפואה דחופה זיהומים"


class DataProcessing:
    def __init__(self, df, er_df, json):
        self.preprocessing_info = None
        self.feature_order = None
        self.cleaned_df = None
        self.diagnose_data = None
        self.diagnoses_group = None
        self.dates_data = None
        self.df = df
        self.er_df = er_df

    @staticmethod
    # checking if string in the correct date format
    def is_date(string):
        date_pattern = r'\b\d{4}-\d{1,2}-\d{1,2}\b'
        match = re.search(date_pattern, string)
        if match:
            return True
        else:
            return False

    @staticmethod
    def is_not_empty_or_whitespace(s):
        return bool(s.strip())

    @staticmethod
    def extractDate(string):
        date_pattern = r'\b\d{4}-\d{1,2}-\d{1,2}\b'
        match = re.search(date_pattern, string)
        if match:
            matched_date = match.group()
            return matched_date
        else:
            return None

    @staticmethod
    def sortParameters(parameters):
        parameters = [float(s) for s in parameters]
        parameters = sorted(parameters)
        parameters = [str(value) for value in parameters]  # Convert each value to string
        return parameters

    # checking if string in the correct hour format
    @staticmethod
    def is_hour(string):
        hour_pattern = r'\b\d{2}:\d{2}:\d{2}\b'
        match = re.search(hour_pattern, string)
        if match:
            return True
        else:
            return False

    @staticmethod
    def extractHour(string):
        hour_pattern = r'\b\d{2}:\d{2}:\d{2}\b'
        match = re.search(hour_pattern, string)
        if match:
            matched_hour = match.group()
            return matched_hour
        else:
            return None

    @staticmethod
    def is_hebrew(word):
        for char in word:
            if '\u0590' <= char <= '\u05FF':
                return True
        return False

    # checking if the column contains date

    def is_date_col(self, column_data):
        if isinstance(column_data, pd.Series):
            column_data = column_data.tolist()
        return all(self.is_date(str(value)) or self.is_hour(str(value)) for value in column_data if
                   str(value).strip())  # Ignore empty strings

    @staticmethod
    def get_day_of_week(date_string):
        date_format = "%Y-%m-%d"
        # Parse the date string into a datetime object
        date_obj = datetime.strptime(date_string, date_format)
        # Format the datetime object to get the day of the week
        # %A returns the full weekday name
        day_of_week = date_obj.strftime("%A")
        return day_of_week

    @staticmethod
    def get_month_name(date_string, date_format="%Y-%m-%d"):
        # Parse the date string into a datetime object
        date_obj = datetime.strptime(date_string, date_format)
        # Format the datetime object to get the full month name
        month_name = date_obj.strftime("%B")
        return month_name

    # handles the  sub menu of the date and hour categories
    def handle_date_data(self, selected_parameter):
        if selected_parameter == "sort by hours":
            return self.dates_data["hour"]

        elif selected_parameter == "sort by the day of the week":
            all_days = []
            for date in self.dates_data["date"]:
                day = self.get_day_of_week(date)
                all_days.append(day)
            return all_days

        elif selected_parameter == "sort by months":
            all_months = []
            for date in self.dates_data["date"]:
                month = self.get_month_name(date)
                all_months.append(month)
            return all_months

        elif selected_parameter == "sort by years":
            all_years = []
            for date in self.dates_data["date"]:
                year = date.split("-")[0]
                all_years.append(year)
            return all_years

    # handles the  sub menu of the date and hour categories fo ER data
    def handle_ER_date_data(self, selected_parameter, data):

        dates_list = [date for date in self.er_df[ER_ARRIVAL_DATE] if not pd.isna(date)]
        dates_list = [self.extractDate(str(date)) for date in dates_list]

        if selected_parameter == "sort by the day of the week":
            all_days = {}
            for key, value in data.items():
                for date in dates_list:
                    if date in key:
                        day = self.get_day_of_week(date)
                        if day in all_days:
                            all_days[day] += value
                        else:
                            all_days[day] = value
            return all_days

        elif selected_parameter == "sort by months":
            all_months = {}
            for key, value in data.items():
                for date in dates_list:
                    if date in key:
                        month = self.get_month_name(date)
                        if month in all_months:
                            all_months[month] += value
                        else:
                            all_months[month] = value
            return all_months

        elif selected_parameter == "sort by years":
            all_years = {}
            for key, value in data.items():
                for date in dates_list:
                    if date in key:
                        year = date.split("-")[0]
                        if year in all_years:
                            all_years[year] += value
                        else:
                            all_years[year] = value
            return all_years

    def process_dates_data(self, parameters):
        date = [self.extractDate(parameter) for parameter in parameters if
                parameter and self.is_date(parameter)]
        hour = [self.extractHour(parameter) for parameter in parameters if
                parameter and self.is_hour(parameter)]
        hour = [h.split(":")[0] for h in hour]
        hour = self.sortParameters(hour)
        self.dates_data = {"hour": hour, "date": date}

    def process_er_data(self):
        date_col = ER_ARRIVAL_DATE
        load_info = {}
        sum_load_info = {}
        df_cleaned = []
        relevant_columns = [WALKING_ER, INTERNAL_ER, INTERNAL_ER_INF]

        for col in self.er_df.columns:
            # Check if the current column is one of the specified ER departments/services
            if col in relevant_columns:
                # Drop rows where data in either the current column or the date column is missing
                df_cleaned = self.er_df.dropna(subset=[col, date_col])
                # Iterate over the rows in the cleaned DataFrame

        for index, row in df_cleaned.iterrows():
            for col in relevant_columns:
                # Get the date from the date column
                date = self.extractDate(row[date_col])
                # If the date is not already in the load_info dictionary, initialize it with an empty list
                if date not in load_info:
                    load_info[date] = []
                    # Append the value from the current ER department/service column to the list for this date
                load_info[date].append(row[col])

        for key, value in load_info.items():
            sum = 0
            for v in value:
                sum += v
                sum_load_info[key] = sum

        return sum_load_info

    # extracts the doctor's name
    @staticmethod
    def process_doctors_data(parameters):
        pattern_to_remove = r'מ\.ר\.\d+'
        all_cleaned_data = []
        for parameter in parameters:
            # Use re.sub() to replace the matched pattern with an empty string
            cleaned_data = re.sub(pattern_to_remove, '', parameter).strip()
            all_cleaned_data.append(cleaned_data)
        return all_cleaned_data

    def preprocess_data(self, selected_column, json_data):
        self.diagnoses_group = json_data["diagnoses"]
        self.diagnose_data = self.df[selected_column]

        # Combine conversion to string, removal of brackets, and stripping in one list comprehension
        self.diagnose_data = [str(x).replace("[", "").replace("]", "").strip() for x in self.diagnose_data]

        # Split the strings by commas and strip whitespace in one step using a nested list comprehension
        self.diagnose_data = [item.strip() for s in self.diagnose_data for item in s.split(',')]

    def process_diagnose_data(self, selected_column):
        all_data = []
        for x in self.diagnoses_group[selected_column]:
            for y in self.diagnose_data:
                if x == y:
                    all_data.append(x)
        return all_data

    @staticmethod
    def isNumericData(parameters):
        for value in parameters:
            try:
                float(value)
            except ValueError:
                return False
        return True

    # clean the data for ml usage
    def clean_data(self, predictors, target):
        """Clean the data by filling missing values for numeric and non-numeric columns."""
        df_clean = self.df[predictors + [target]].copy()

        numeric_cols = [col for col in df_clean.columns if self.is_numeric_data(df_clean[col])]
        non_numeric_cols = [col for col in df_clean.columns if not self.is_numeric_data(df_clean[col])]

        if numeric_cols:
            imputer_numeric = SimpleImputer(strategy='mean')
            df_clean[numeric_cols] = imputer_numeric.fit_transform(df_clean[numeric_cols])

        if non_numeric_cols:
            imputer_non_numeric = SimpleImputer(strategy='most_frequent')
            df_clean[non_numeric_cols] = imputer_non_numeric.fit_transform(df_clean[non_numeric_cols])

        df_clean.dropna(subset=predictors, inplace=True)

        return df_clean

    def convert_dates_and_times(self, df, predictors):
        """Convert date and time columns into meaningful categories."""
        for column in predictors:
            if 'date' in column.lower() or 'time' in column.lower() or column in ['תאריך וזמן שחרור']:
                df[column] = pd.to_datetime(df[column], errors='coerce')

                if df[column].dtype == 'datetime64[ns]':
                    df[f'{column}_time_of_day'] = df[column].dt.hour.apply(self.categorize_time_of_day)
                    df.drop(column, axis=1, inplace=True)

        return df

# split the hours to different categories for ml usage
    @staticmethod
    def categorize_time_of_day(hour):
        """Categorize the hour into numerical values representing parts of the day."""
        if pd.isnull(hour):
            return -1  # For missing values
        if 0 <= hour < 6:
            return 0  # Late Night
        elif 6 <= hour < 12:
            return 1  # Morning
        elif 12 <= hour < 18:
            return 2  # Afternoon
        elif 18 <= hour < 24:
            return 3  # Evening
        else:
            return -1  # Invalid hour

    def initialize_preprocessing_info(self, X):
        self.preprocessing_info = {}
        for column in X.columns:
            if '_hour_category' in column:
                original_column = column.replace('_hour_category', '')
                self.preprocessing_info[original_column] = '_hour_category'
            elif self.is_numeric_data(X[column]):
                self.preprocessing_info[column] = 'numeric'
            else:
                self.preprocessing_info[column] = 'other'

    def save_preprocessing_info(self, x):
        self.preprocessing_info = {}
        for column in x.columns:
            if '_hour_category' in column:
                original_column = column.replace('_hour_category', '')
                self.preprocessing_info[original_column] = '_hour_category'

            elif self.is_numeric_data(x[column]):
                self.preprocessing_info[column] = 'numeric'
            else:
                self.preprocessing_info[column] = 'other'

    def preprocess_new_patient(self, patient_data):
        if not self.preprocessing_info:
            messagebox.showinfo("Warning: preprocessing_info is empty. Using default processing.")
            # Add default processing logic here if needed

        processed_data = {}

        for column, value in patient_data.items():
            if self.preprocessing_info.get(column) == '_hour_category':
                if isinstance(value, tuple):
                    hour, minute = value
                    processed_hour = int(hour.get())
                else:
                    hour = self.extractHour(value)
                    processed_hour = int(hour[:2]) if hour else None
                if processed_hour is not None:
                    processed_data[f"{column}_hour_category"] = self.categorize_time_of_day(processed_hour)
                else:
                    processed_data[f"{column}_hour_category"] = -1
            elif self.preprocessing_info.get(column) == 'numeric':
                processed_data[column] = float(value)
            else:
                processed_data[column] = value

        # Create DataFrame from processed_data
        df = pd.DataFrame([processed_data])

        if self.feature_order is not None:
            # Ensure all columns from the original data are present
            for column in self.feature_order:
                if column not in df.columns:
                    if '_hour_category' in column:
                        # If it's a missing hour category, set it to a default value (e.g., -1)
                        df[column] = -1
                    else:
                        df[column] = None

            # Reorder columns to match feature_order
            df = df.reindex(columns=self.feature_order, fill_value=None)

        return df

    def preprocess_data_for_ML(self, df_clean, predictors, target):
        y = df_clean[target]
        x = df_clean[predictors].copy()  # Create a copy of the predictors DataFrame

        # Prepare the predictor variables
        for column in predictors:
            column_data = x[column]
            parameters = column_data.astype(str)  # Convert to string

            # Check if the column contains date and time values
            if self.is_date_col(parameters.iloc[1:]):  # Skip the first value to avoid blank issues
                # Extract the hour and categorize
                hours = [self.extractHour(param) for param in parameters]
                hours = [int(hour[:2]) if hour else -1 for hour in
                         hours]  # Extract the hour part (HH) and convert to int
                x[f"{column}_hour_category"] = [self.categorize_time_of_day(hour) for hour in hours]  # Categorize hours
                x.drop(columns=[column], inplace=True)  # Remove the original date column
            else:
                x[column] = pd.to_numeric(parameters, errors='coerce')  # Convert to numeric

        # Prepare the target variable for classification
        y = y.apply(lambda w: 0 if 1 <= w <= 10 else (1 if 11 <= w <= 20 else 2))
        y = y.astype('category')

        # Fill NaN values with -1 for hour categories
        hour_category_columns = [col for col in x.columns if '_hour_category' in col]
        x[hour_category_columns] = x[hour_category_columns].fillna(-1)

        # Save the preprocessed x and y data to self.cleaned_df
        self.cleaned_df = pd.concat([x, y], axis=1)

        # Remove rows with -1 values from x only
        x = x[(x != -1).all(axis=1)]

        # Save preprocessing information
        self.save_preprocessing_info(x)

        # Set the feature_order attribute with the column names of x
        self.feature_order = x.columns.tolist()

        # Filter y to match the remaining rows in x
        y = y.loc[x.index]
        return x, y

    @staticmethod
    def save_to_excel(X, y, filename):
        """Save the processed data to an Excel file."""
        df_combined = pd.concat([X, y], axis=1)
        df_combined.to_excel(filename, index=False)

    @staticmethod
    def is_numeric_data(column_data):
        """Check if the data in the column is numeric."""
        try:
            pd.to_numeric(column_data)
            return True
        except ValueError:
            return False

    def save_processed_data(self, filename='processed_data.pkl'):
        with open(filename, 'wb') as f:
            pickle.dump({
                'df': self.cleaned_df,
                'preprocessing_info': self.preprocessing_info,
                'feature_order': self.feature_order
            }, f)

    def load_processed_data(self, filename='processed_data.pkl'):
        try:
            with open(filename, 'rb') as f:
                data = pickle.load(f)
                self.cleaned_df = data['df']
                self.preprocessing_info = data['preprocessing_info']
                self.feature_order = data['feature_order']
            return True
        except FileNotFoundError:
            return False
