import os
import pickle
from DataProcessing import DataProcessing
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier


class MachineLearning:
    def __init__(self, df, app, er_df, json):
        self.last_f1_score = None
        self.last_recall = None
        self.last_precision = None
        self.last_accuracy = None
        self.training_models_page = None
        self.selected_algorithm = None
        self.df = df
        self.target = 'זמן (בימים) מהשחרור הראשון ועד לאשפוז הבא'
        self.predictors = ['גיל', 'תאריך וזמן שחרור', 'משך אשפוז']
        self.data_processing = DataProcessing(df, er_df, json)
        self.app = app
        self.trained_model = None
        self.n_runs = 5
        self.X = None
        self.y = None
        self.X_scaled = None
        self.filter = ""
        self.age_for_column = 'גיל'
        self.processed_ml_data_file = 'processed_ml_data.pkl'
        self.df_for_ml = None
        self.load_or_process_data()

    # check if processed_ml_data_file exist, if not its making it
    def load_or_process_data(self):
        if os.path.exists(self.processed_ml_data_file):
            self.load_processed_data()
        else:
            self.process_for_ml()

    # load processed_ml_data_file
    def load_processed_data(self):
        with open(self.processed_ml_data_file, 'rb') as f:
            data = pickle.load(f)
            self.df_for_ml = data['df_for_ml']
            self.X = data['X']
            self.y = data['y']
            self.data_processing.preprocessing_info = data['preprocessing_info']
            self.data_processing.feature_order = data['feature_order']
            self.data_processing.cleaned_df = self.df_for_ml  # Assign df_for_ml to cleaned_df

    # save processed_ml_data_file
    def save_processed_data(self):
        with open(self.processed_ml_data_file, 'wb') as f:
            pickle.dump({
                'df_for_ml': self.df_for_ml,
                'X': self.X,
                'y': self.y,
                'preprocessing_info': self.data_processing.preprocessing_info,
                'feature_order': self.data_processing.feature_order
            }, f)

    # clean and prepare df for ml
    def process_for_ml(self):
        if self.df is not None and not self.df.empty:
            self.df.columns = self.df.columns.str.strip()

            for col in self.predictors + [self.target]:
                if col not in self.df.columns:
                    raise KeyError(f"Column '{col}' not found in DataFrame")

            df_clean = self.data_processing.clean_data(self.predictors, self.target)

            if df_clean.empty:
                raise ValueError("The DataFrame is empty after cleaning. Please check your data.")
            self.df_for_ml = df_clean  # Store the cleaned data
            self.data_processing.cleaned_df = self.df_for_ml  # Assign df_for_ml to cleaned_df
            self.X, self.y = self.data_processing.preprocess_data_for_ML(df_clean, self.predictors, self.target)

            # Initialize preprocessing info
            self.data_processing.initialize_preprocessing_info(self.X)
            self.save_processed_data()

    @staticmethod
    def split_test_train(X, y, test_size=0.2, random_state=None):
        x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)

        return x_train, x_test, y_train, y_test

    @staticmethod
    def create_pipeline(algorithm):
        if algorithm == "Support Vector Machines":
            model = SVC(class_weight='balanced', probability=True)
            param_grid = {
                'classifier__C': [0.1, 1, 10],
                'classifier__kernel': ['linear', 'rbf'],
                'classifier__gamma': ['scale', 'auto']
            }
        elif algorithm == "K-Nearest Neighbors":
            model = KNeighborsClassifier()
            param_grid = {
                'classifier__n_neighbors': [3, 5, 7],
                'classifier__weights': ['uniform', 'distance'],
                'classifier__algorithm': ['ball_tree', 'kd_tree', 'auto']
            }
        elif algorithm == "Decision Trees":
            model = DecisionTreeClassifier(class_weight='balanced')
            param_grid = {
                'classifier__criterion': ['gini', 'entropy'],
                'classifier__max_depth': [None, 5, 10, 15],
                'classifier__min_samples_split': [2, 5, 10]
            }
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
        pipeline = ImbPipeline(steps=[
            ('undersampler', RandomUnderSampler(random_state=0)),
            ('scaler', StandardScaler() if algorithm != "Decision Trees" else None),
            ('classifier', model)
        ])

        pipeline.steps = [step for step in pipeline.steps if step[1] is not None]
        return pipeline, param_grid

    @staticmethod
    def calculate_metrics(y_true, y_pred):
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
        recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
        f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0)
        return accuracy, precision, recall, f1

    # train and fit according to the algorithm selected
    def train_fit_by_algorithm(self, X_train, y_train, algorithm):
        pipeline, param_grid = self.create_pipeline(algorithm)

        grid_search = GridSearchCV(pipeline, param_grid, cv=5, n_jobs=-1)
        grid_search.fit(X_train, y_train)

        model = grid_search.best_estimator_
        return model

    def save_model(self, model, model_name, age_range):

        model_info = {
            "model": model,
            "model_name": model_name,
            "age_range": age_range,
            "preprocessing_info": self.data_processing.preprocessing_info,
            "feature_order": self.data_processing.feature_order
        }
        filename = f"{model_name}_{age_range}.pkl"
        with open(filename, "wb") as file:
            pickle.dump(model_info, file)

    def save_trained_model(self, model_key):
        if not model_key.endswith("_model"):
            model_key += "_model"
        model_filename = f"{model_key}.pkl"
        model_info = {
            'model': self.trained_model,
            'model_name': self.selected_algorithm,
            'filter': self.filter,
            'accuracies': self.training_models_page.model_results[model_key]['accuracies'],
            'precisions': self.training_models_page.model_results[model_key]['precisions'],
            'recalls': self.training_models_page.model_results[model_key]['recalls'],
            'f1_scores': self.training_models_page.model_results[model_key]['f1_scores'],
            'preprocessing_info': self.data_processing.preprocessing_info,
            'feature_order': self.data_processing.feature_order
        }
        with open(model_filename, 'wb') as file:
            pickle.dump(model_info, file)

    def train_ml_model(self, algorithm):
        if algorithm:
            self.selected_algorithm = algorithm

            x_train, x_test, y_train, y_test = self.split_test_train(
                self.X, self.y, test_size=0.2, random_state=0
            )

            if algorithm == "Support Vector Machines":
                scaler = StandardScaler()
                x_train = scaler.fit_transform(x_train)
                x_test = scaler.transform(x_test)

            self.trained_model = self.train_fit_by_algorithm(x_train, y_train, algorithm)
            y_pred = self.predict(x_test)
            accuracy, precision, recall, f1 = self.calculate_metrics(y_test, y_pred)

            model_key = f"{algorithm}_{self.filter}"
            self.training_models_page.model_results[model_key] = {
                'accuracies': [accuracy],
                'precisions': [precision],
                'recalls': [recall],
                'f1_scores': [f1],
                'filters': self.filter
            }

            # Return the results instead of saving the model here
            return {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1_score': f1
            }

    def predict(self, X_test):
        if self.trained_model is not None:
            return self.trained_model.predict(X_test)
        else:
            return None

    def predict_proba(self, X):
        if self.trained_model is not None:
            return self.trained_model.predict_proba(X)
        else:
            return None

    def get_age_range(self):
        if self.age_for_column in self.X.columns:
            return self.X[self.age_for_column].min(), self.X[self.age_for_column].max()
        else:
            return None, None

    def set_training_models_page(self, train_models_page):
        self.training_models_page = train_models_page
