import os
import pickle
import tkinter as tk
from tkinter import messagebox


class TrainingModelsPage:
    def __init__(self, ml, application):
        self.model_key = None
        self.ml = ml
        self.application = application
        self.window = None
        self.button_frame = None
        self.header_label = None
        self.model_results = {}  # Store evaluation results for each model
        self.trained_models = set()  # Store the names of trained models
        self.model_buttons = {}
        self.application = application
        self.load_saved_models()

        self.button_style = {
            'bg': '#90ee90',
            'fg': 'black',
            'bd': 1,
            'relief': 'groove',
            'highlightthickness': 5,
            'padx': 20,
            'pady': 10,
        }

    # run train models page
    def run(self):
        train_models_window = tk.Toplevel(self.application.window)
        train_models_window.title("Train Models")
        train_models_window.geometry("800x600")
        train_models_window.configure(bg="#051a1c")

        self.window = train_models_window
        self.clear_frame()
        self.create_page()

    # load all models from pkl files
    def load_saved_models(self):
        for file in os.listdir():
            if file.endswith("_model.pkl"):
                try:
                    with open(file, "rb") as f:
                        model_info = pickle.load(f)
                    if isinstance(model_info, dict) and "model" in model_info:
                        model_key = file[:-4]  # Remove .pkl
                        if model_key not in self.model_results:
                            self.model_results[model_key] = {
                                'accuracies': model_info.get('accuracies', []),
                                'precisions': model_info.get('precisions', []),
                                'recalls': model_info.get('recalls', []),
                                'f1_scores': model_info.get('f1_scores', []),
                                'filters': model_info.get('filter', 'N/A')
                            }
                            self.trained_models.add(model_key)
                except Exception as e:
                    messagebox.showinfo(f"Error loading model {file}: {e}")

    def clear_frame(self):
        for widget in self.window.winfo_children():
            widget.destroy()

    # create training models page
    def create_page(self):
        self.button_frame = tk.Frame(self.window, bg='#051a1c')
        self.button_frame.pack(fill='both', expand=True)

        self.header_label = tk.Label(self.button_frame, text="Select Machine Learning Algorithm", bg="#051a1c",
                                     fg="white")
        self.header_label.pack(side='top', fill='x')
        show_results_button = tk.Button(self.button_frame, text="Show Evaluation Results",
                                        command=lambda: self.show_evaluation_results(self.model_results), width=25,
                                        height=2,
                                        **self.button_style)

        show_results_button.pack(side='bottom', pady=10)

        self.create_age_filter_frame()

        decision_trees_button = tk.Button(self.button_frame, text="Decision Trees",
                                          command=lambda: self.train_and_update_button('Decision Trees',
                                                                                       decision_trees_button),
                                          **self.button_style)
        support_vector_machines_button = tk.Button(self.button_frame, text="Support Vector Machines",
                                                   command=lambda: self.train_and_update_button(
                                                       "Support Vector Machines", support_vector_machines_button),
                                                   **self.button_style)
        k_nearest_neighbors_button = tk.Button(self.button_frame, text="K-Nearest Neighbors",
                                               command=lambda: self.train_and_update_button("K-Nearest Neighbors",
                                                                                            k_nearest_neighbors_button),
                                               **self.button_style)

        decision_trees_button.pack(side='top', fill='x', pady=5)
        support_vector_machines_button.pack(side='top', fill='x', pady=5)
        k_nearest_neighbors_button.pack(side='top', fill='x', pady=5)

        self.model_buttons = {
            'Decision Trees': decision_trees_button,
            'Support Vector Machines': support_vector_machines_button,
            'K-Nearest Neighbors': k_nearest_neighbors_button
        }

        back_button = tk.Button(self.button_frame, text="Back to Home", command=self.back_to_home, width=25, height=2,
                                **self.button_style)
        back_button.pack(side='bottom', pady=10)

    def create_age_filter_frame(self):
        age_filter_frame = tk.Frame(self.button_frame)
        age_filter_frame.pack(side='top', pady=10)

        min_age, max_age = self.ml.get_age_range()
        age_filter_label = tk.Label(age_filter_frame, text=f"Age Range Filter (Current: {min_age} to {max_age}):")
        age_filter_label.pack(side='left')

        min_age_entry = tk.Entry(age_filter_frame, width=5)
        min_age_entry.pack(side='left')

        to_label = tk.Label(age_filter_frame, text="to")
        to_label.pack(side='left')

        max_age_entry = tk.Entry(age_filter_frame, width=5)
        max_age_entry.pack(side='left')

        filter_button = tk.Button(age_filter_frame, text="Filter",
                                  command=lambda: self.filter_age_range(min_age_entry.get(), max_age_entry.get()))
        filter_button.pack(side='left', padx=5)

        reset_button = tk.Button(age_filter_frame, text="Reset",
                                 command=self.reset_age_filter)
        reset_button.pack(side='left')

    def filter_age_range(self, min_age, max_age):
        try:
            min_age = int(min_age)
            max_age = int(max_age)

            # Get the actual age range from the processed data
            data_min_age, data_max_age = self.ml.get_age_range()

            if min_age > max_age:
                raise ValueError("please enter a valid range")

            if data_min_age is None or data_max_age is None:
                raise ValueError("Age column not found in the processed data.")

            if min_age < data_min_age or max_age > data_max_age:
                raise ValueError(
                    f"Please enter valid integer values for age range. Minimum age is: {data_min_age}, maximum age is: {data_max_age}")
            else:
                self.ml.X = self.ml.X[
                    (self.ml.X[self.ml.age_for_column] >= min_age) & (self.ml.X[self.ml.age_for_column] <= max_age)]
                self.ml.y = self.ml.y[self.ml.X.index]
                self.ml.filter = f"{min_age} to {max_age}"
                messagebox.showinfo("Age Range Filter", f"Data filtered for age range: {min_age} to {max_age}")
                self.enable_algorithm_buttons()  # Enable all algorithm buttons
        except ValueError as e:
            messagebox.showinfo("Invalid Input", str(e))

    def reset_age_filter(self):
        self.ml.load_processed_data()
        min_age, max_age = self.ml.get_age_range()
        self.ml.filter = f"{min_age} to {max_age}"
        messagebox.showinfo("Age Range Filter", f"Age range filter has been reset to {min_age} to {max_age}.")
        self.enable_algorithm_buttons()  # Enable all algorithm buttons

    def train_and_update_button(self, algorithm, button):
        model_key = f"{algorithm}_{self.ml.filter}"
        if not model_key.endswith("_model"):
            model_key += "_model"
        model_filename = f"{model_key}.pkl"

        if model_key in self.model_results:
            messagebox.showinfo("Model Exists", f"A model named '{model_key}' with the same age filter already exists.")
            return

        results = self.ml.train_ml_model(algorithm)

        self.model_results[model_key] = {
            'accuracies': [results['accuracy']],
            'precisions': [results['precision']],
            'recalls': [results['recall']],
            'f1_scores': [results['f1_score']],
            'filters': self.ml.filter
        }

        self.trained_models.add(model_key)
        button.configure(text=f"{algorithm} (Trained)", bg="green", fg="white", state="disabled")
        self.update_model_buttons()
        self.ml.save_trained_model(model_key)

        #  a single message after saving the model
        messagebox.showinfo("New model" ,f"'{model_key}' has been trained and saved as {model_filename}")

    def show_evaluation_results(self, model_results):
        result_window = tk.Toplevel(self.window)
        result_window.title("Evaluation Results")
        result_window.geometry("1000x600")
        result_window.configure(bg="#051a1c")

        table_frame = tk.Frame(result_window)
        table_frame.pack(padx=20, pady=20)

        headers = ["Model", "Accuracy", "Precision", "Recall", "F1-score", "Filter"]
        for col, header in enumerate(headers):
            label = tk.Label(table_frame, text=header, font=("Arial", 12, "bold"), padx=10, pady=5)
            label.grid(row=0, column=col)

        row = 1
        displayed_models = set()  # Keep track of displayed models
        for model_key, results in model_results.items():
            # Remove trailing underscore from model key for comparison
            base_model_key = model_key[:-6] if model_key.endswith("_model") else model_key

            if base_model_key in displayed_models:
                continue  # Skip displaying the model if it's already displayed

            displayed_models.add(base_model_key)  # Mark the model as displayed

            model_label = tk.Label(table_frame, text=model_key, font=("Arial", 10, "bold"), padx=10, pady=5)
            model_label.grid(row=row, column=0)

            metrics = [
                self.calculate_average(results['accuracies']),
                self.calculate_average(results['precisions']),
                self.calculate_average(results['recalls']),
                self.calculate_average(results['f1_scores']),
                results['filters']
            ]

            for col, metric in enumerate(metrics, start=1):
                metric_label = tk.Label(table_frame, text=metric, font=("Arial", 10), padx=10, pady=5)
                metric_label.grid(row=row, column=col)

            row += 1

        self.update_model_buttons()

    @staticmethod
    def calculate_average(values):
        valid_values = [v for v in values if v is not None]
        if valid_values:
            return f"{sum(valid_values) / len(valid_values):.2f}"
        else:
            return "N/A"

    def enable_algorithm_buttons(self):
        for button in self.model_buttons.values():
            button.config(state="normal")

    def update_model_buttons(self):
        for model, button in self.model_buttons.items():
            if model in self.trained_models:
                button.configure(text=f"{model} (Trained)", bg="green", fg="white", state="disabled")
            else:
                button.configure(text=model, bg=self.button_style['bg'], fg=self.button_style['fg'], state="normal")

    def back_to_home(self):
        self.application.back_to_home()
