import tkinter as tk
from tkinter import ttk, messagebox
import os
import pickle

import numpy as np


class SavedModelsPage:
    def __init__(self, window, ml):
        self.window = window
        self.ml = ml
        self.canvas = None
        self.sort_var = None
        self.window = window
        self.ml = ml
        self.dp = ml.data_processing
        self.model_frames = {}
        self.current_patient = None
        self.patient_data_entries = {}
        self.patient_data_label = None
        self.valid_models = self.load_available_models()
        self.save_patient_button = None
        self.sort_var = tk.StringVar(value="date")  # Initialize here

    # load all models from pkl files
    @staticmethod
    def load_available_models():
        valid_models = {}
        for file in os.listdir():
            if file.endswith("_model.pkl"):
                try:
                    with open(file, "rb") as f:
                        model_info = pickle.load(f)
                    if isinstance(model_info, dict) and "model" in model_info:
                        model_key = file[:-len("_model.pkl")]
                        valid_models[model_key] = model_info
                except Exception as e:
                    messagebox.showinfo(f"Error loading model {file}: {e}")
        return valid_models

    def create_page_layout(self):
        # Create patient input fields
        self.create_patient_input_fields()

        # Save Patient button
        self.save_patient_button = ttk.Button(self.window, text="Save Patient", command=self.save_patient)
        self.save_patient_button.pack(pady=10)

        # Label to display saved patient data
        self.patient_data_label = ttk.Label(self.window, text="No patient data saved", wraplength=400)
        self.patient_data_label.pack(pady=10)

        # Create the model table
        self.create_model_table()

    def create_patient_input_fields(self):
        input_frame = ttk.LabelFrame(self.window, text="New Patient Data")
        input_frame.pack(padx=10, pady=10, fill='both', expand=True)

        sample_row = self.dp.cleaned_df.iloc[0]

        for i, predictor in enumerate(self.ml.predictors):
            label = ttk.Label(input_frame, text=predictor)
            label.grid(row=i, column=0, padx=5, pady=5, sticky='e')

            if self.dp.is_date_col([str(sample_row[predictor])]):
                # Create time spin boxes for hours and minutes
                hour_var = tk.StringVar(value="00")
                hour_spinbox = ttk.Spinbox(input_frame, from_=0, to=23, width=2, format="%02.0f",
                                           textvariable=hour_var, wrap=True,
                                           command=lambda v=hour_var: v.set(f"{int(v.get()):02d}"))
                hour_spinbox.grid(row=i, column=1, padx=5, pady=5)

                minute_var = tk.StringVar(value="00")
                minute_spinbox = ttk.Spinbox(input_frame, from_=0, to=59, width=2, format="%02.0f",
                                             textvariable=minute_var, wrap=True,
                                             command=lambda v=minute_var: v.set(f"{int(v.get()):02d}"))
                minute_spinbox.grid(row=i, column=2, padx=5, pady=5)

                self.patient_data_entries[predictor] = (hour_spinbox, minute_spinbox)
            else:
                # Create regular entry field for non-date/time data
                entry = ttk.Entry(input_frame)
                entry.grid(row=i, column=1, columnspan=2, padx=5, pady=5)
                self.patient_data_entries[predictor] = entry

    def predict_for_model(self, model_file):
        if self.current_patient is None:
            messagebox.showerror("Error", "Please save the patient data first.")
            return

        model_info = self.valid_models[model_file]
        self.ml.trained_model = model_info["model"]

        # Ensure preprocessing info is set for each prediction
        if "preprocessing_info" in model_info:
            self.dp.preprocessing_info = model_info["preprocessing_info"]
        else:
            print("Warning: preprocessing_info not found in model_info")

        if "feature_order" in model_info:
            self.dp.feature_order = model_info["feature_order"]
        else:
            print("Warning: feature_order not found in model_info")

        try:
            new_patient_x = self.dp.preprocess_new_patient(self.current_patient)
            probabilities = self.ml.predict_proba(new_patient_x)

            if probabilities is not None:
                group_labels = {0: "Group 0 (1-10 days)", 1: "Group 1 (11-20 days)", 2: "Group 2 (>20 days)"}
                predicted_group = np.argmax(probabilities[0])
                result_text = f"Predicted class: {group_labels[predicted_group]}\n\n"
                result_text += "Class probabilities:\n"
                for group, prob in enumerate(probabilities[0]):
                    result_text += f"{group_labels[group]}: {prob:.2f}\n"
                self.model_frames[model_file]['result_label'].config(text=result_text)
            else:
                messagebox.showerror("Error", "Failed to get prediction probabilities.")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    # save new patient for prediction
    def save_patient(self):
        if not self.patient_data_entries:
            messagebox.showerror("Error", "No patient data to save.")
            return

        self.current_patient = {}
        for predictor, entry in self.patient_data_entries.items():
            if isinstance(entry, tuple):
                hour = entry[0].get().zfill(2)  # Ensure 2-digit format
                minute = entry[1].get().zfill(2)  # Ensure 2-digit format
                self.current_patient[predictor] = f"{hour}:{minute}:00"
            else:
                self.current_patient[predictor] = entry.get()

        # Update the patient data label
        patient_data_text = "Saved Patient Data:\n" + "\n".join(f"{k}: {v}" for k, v in self.current_patient.items())
        self.patient_data_label.config(text=patient_data_text)

        # Enable all predict buttons
        for model_frame in self.model_frames.values():
            model_frame['predict_button'].config(state='normal')

        messagebox.showinfo("Patient Saved", "Patient data has been saved. You can now predict using any model.")

    # update ml ui
    def update_model_table(self):
        if not self.canvas:
            return  # Exit if canvas is not initialized

        inner_frame = self.canvas.winfo_children()[0]
        for widget in inner_frame.winfo_children():
            widget.destroy()

        headers = ['Saved Model', 'Predict', 'Result']
        for col, header in enumerate(headers):
            label = ttk.Label(inner_frame, text=header, font=('Arial', 12, 'bold'))
            label.grid(row=0, column=col, padx=5, pady=5, sticky='w')

        saved_models = list(self.valid_models.items())

        sort_value = self.sort_var.get() if self.sort_var else "date"
        if sort_value == "date":
            sorted_models = sorted(saved_models, key=lambda x: os.path.getmtime(x[0] + "_model.pkl"), reverse=True)
        else:
            sorted_models = sorted(saved_models, key=lambda x: x[0])

        for row, (model_key, model_info) in enumerate(sorted_models, start=1):
            model_label = ttk.Label(inner_frame, text=model_key)
            model_label.grid(row=int(row), column=0, padx=5, pady=5, sticky='w')

            predict_button = ttk.Button(inner_frame, text="Predict",
                                        command=lambda m=model_key: self.predict_for_model(m),
                                        state='normal')  # Change this to 'normal'
            predict_button.grid(row=int(row), column=1, padx=5, pady=5)

            result_label = ttk.Label(inner_frame, text="")
            result_label.grid(row=int(row), column=2, padx=5, pady=5, sticky='w')

            self.model_frames[model_key] = {
                'predict_button': predict_button,
                'result_label': result_label
            }

        # Update the scroll region
        inner_frame.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def refresh_models(self):
        self.valid_models = self.load_available_models()
        self.update_model_table()

    def change_window(self, new_window):
        self.window = new_window

    def create_model_table(self):
        table_frame = ttk.LabelFrame(self.window, text="Available Models")
        table_frame.pack(padx=10, pady=10, fill='both', expand=True)

        # Create a canvas
        self.canvas = tk.Canvas(table_frame)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Add a scrollbar to the canvas
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Configure the canvas
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        # Create another frame inside the canvas
        inner_frame = ttk.Frame(self.canvas)

        # Add that new frame to a window in the canvas
        self.canvas.create_window((0, 0), window=inner_frame, anchor="nw")

        # Initially populate the table
        self.update_model_table()

    def run(self):
        self.window.title("Saved Models")
        self.window.geometry("800x600")

        self.create_page_layout()
        self.refresh_models()

        self.sort_var.set("date")  # Just set the value, don't create a new StringVar

        sort_label = ttk.Label(self.window, text="Sort by:")
        sort_label.pack()

        sort_date_radio = ttk.Radiobutton(self.window, text="Latest Model Saved", variable=self.sort_var, value="date")
        sort_date_radio.pack()

        sort_type_radio = ttk.Radiobutton(self.window, text="Model Type", variable=self.sort_var, value="type")
        sort_type_radio.pack()

        sort_date_radio.configure(command=self.update_model_table)
        sort_type_radio.configure(command=self.update_model_table)
